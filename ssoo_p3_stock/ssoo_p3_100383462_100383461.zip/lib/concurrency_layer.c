#include <pthread.h>
#include <stdio.h>
#include <string.h>
//#include <.h>
#include "../include/concurrency_layer.h"

// 1. Initialize concurrency mechanisms
// 2. Destroy concurrency mechanisms
// 3. Broker
//    - Inserts stock trades on the queue of the market.
//    $ There may be n concurrent threads running a broker.
//    $ Each one only runs one operation.
// 4. Operation Executer
//    - Processes operations of the queue one by one.
//    $ Only one thread running the process.
// 5. Stats Reader
//    - Reads the current state of the market.
//    $ There can be n concurrent readers and run simultaneously
//    $$ WHILE IT'S READING NO MODIFICATION ON THE MARKET SHALL BE DONE
//    $$$ by brokers or operation executers.

//

// Broker ^ Operation Executers USE <<queue operations>>
// Stats Reader can directly read from the state of the market.

pthread_mutex_t generalQ_mutex;
pthread_mutex_t brokerQ_mutex;
pthread_mutex_t read_mutex;
pthread_mutex_t stateQ_mutex; // NEEDED?

pthread_cond_t freeQ_cond;
pthread_cond_t fullQ_cond;

int conc_readers = 0;

/**
* Initializes the concurrency control mechanisms.
* Always called by the main method.
*/
void init_concurrency_mechanisms(){

  // Initialize the mutex variables.
  pthread_mutex_init(&generalQ_mutex, NULL);
  pthread_mutex_init(&brokerQ_mutex, NULL); // NEEDED?
  pthread_mutex_init(&read_mutex, NULL);
  pthread_mutex_init(&stateQ_mutex, NULL); // NEEDED?

  // Initialize the mutex conditions.
  pthread_cond_init(&freeQ_cond, NULL);
  pthread_cond_init(&fullQ_cond, NULL);
}

/**
* Destroys the initialized concurrency control mechanisms.
* Always called by the main method upon exit.
*/
void destroy_concurrency_mechanisms(){

  // Destroy the mutex variales.
  pthread_mutex_destroy(&generalQ_mutex);
  pthread_mutex_destroy(&brokerQ_mutex);
  pthread_mutex_destroy(&read_mutex);
  pthread_mutex_destroy(&stateQ_mutex);

  // Destroy the mute conditions.
  pthread_cond_destroy(&freeQ_cond);
  pthread_cond_destroy(&fullQ_cond);
}

/**
* Implements the functionality of broker threads + CC
* - char batch_file[256]: name of the batch file containing the transactions.
* - stock_market* market: pointer to the market on which the broker operates.
*/
void* broker(void* args){

  // Create a broker_info structure variable to dereference the arguments.
  struct broker_info * data = args;

  // Extract info from the argument.
  char file[256];
  memcpy(data->batch_file, file, 256);
  operations_queue* market_queue = data->market->stock_operations;

  // Create a new iterator to traverse the operations in the batch file.
  iterator *iter;
  if ((iter = new_iterator(file)) == NULL) {
    printf("ERROR: iterator could not be created. \n");
    //pthread_exit(0);
  }

  // Variables that will be filled with operation details + Counter of operations.
  char* id[11];
  int* type;
  int* num_shares;
  int* price;
  int counter = 0;

  // For every operation, create a new thread that does the job of a broker.
  while (next_operation(iter, *id, type, num_shares, price) >= 0){

    // Create a pointer to hold the operation to be inserted.
    operation *op;
    // Allocate memory to hold the operation avoiding segmentation faults.
    op = (operation*) malloc(sizeof(op));
    // The thread is stopped if there's no space in the queue.
    while(operations_queue_full(market_queue) > 0){
      // Freeze the thread until the signal is sent from the operation_executer;
      pthread_cond_wait(&freeQ_cond, &stateQ_mutex);
    }

    /* --- C R I T I C A L  -  S E C T I O N --- */

    // Lock the access for readers.
    pthread_mutex_lock(&read_mutex);
    // Lock the access to the queue.
    pthread_mutex_lock(&generalQ_mutex);
    // Lock the execution of the broker threads.
    pthread_mutex_lock(&brokerQ_mutex);

    // Pack the data of the operation for insertion.
    new_operation(op, id[11], *type, *num_shares, *price);
    // Insert the operation into the market queue.
    enqueue_operation(market_queue, op);

    // Unlock the access for readers.
    pthread_mutex_unlock(&read_mutex);
    // Unlock the access to the queue.
    pthread_mutex_unlock(&generalQ_mutex);
    // Unlock the execution of the broker threads.
    pthread_mutex_unlock(&brokerQ_mutex);
    /* ------------------------------------------ */

    // Send a signal to the processor thread waiting for operations in the queue.
    pthread_cond_signal(&fullQ_cond);

    // Increase the counter of inserted operations.
    counter++;

  }

  printf("Added %d operations. \n", counter);
  // Destroy the iterator
  destroy_iterator(iter);
}

/**
* Processes the operations introduced in the queue by the brokers.
* - int *exit: pointer to flag termination of the application. If true the
*   thread will process existing requests pending in the queue and terminate.
* - stock_market *market: pointer to the market on which the processor operates.
* - pthread_mutex_t *exit_mutex: pointer to mutex that protects the variable exit.
*   it must access the variable exit always with a locked mutex.
*/
void* operation_executer(void* args){

  // Create a exec_info structure variable to dereference the arguments.
  struct exec_info * data = args;

  // Extract info from the argument. It contains the mutex for the exit variable.
  int *exit = data->exit;
  pthread_mutex_t *exit_mutex = data->exit_mutex;
  stock_market *market = data->market;
  operations_queue *market_queue = data->market->stock_operations;

  // Execution loop - Execute until exit flag is raised
  while(exit != 0){

    // The thread is stopped if there're no operations in the queue.
    while(operations_queue_empty(market_queue) > 0){
      // Freeze the thread until the signal is sent from the operation_executer;
      pthread_cond_wait(&fullQ_cond, &stateQ_mutex);
    }

    // Create a pointer to hold the operation to be processed
    operation *operation;

    /* --- C R I T I C A L  -  S E C T I O N --- */

    // Lock the access for readers.
    pthread_mutex_lock(&read_mutex);
    // Lock the access to the queue.
    pthread_mutex_lock(&generalQ_mutex);

    // Dequeue the operation from the stock.
    dequeue_operation(market_queue, operation);
    // Carry out the operation.
    process_operation(market, operation);

    // Unlock the access for readers.
    pthread_mutex_unlock(&read_mutex);
    // Unlock the access to the queue.
    pthread_mutex_unlock(&generalQ_mutex);
    /* ------------------------------------------ */

    // Send a signal to a thread waiting for space in the queue.
    pthread_cond_signal(&freeQ_cond);

  }
}

/**
* Evaluates the stock exchange market
* - int *exit: pointer to flag termination of the application. When true.
* - stock_market *market: pointer to th emarket on which the consultant operates.
* - pthread_mutex_t *exit_mutex: pointer to the mutex that protects the variable exit.
*   it must access the variable exit always with a locked mutex.
* - unsigned int frequency: time that the thread should sleep after each query (refresh frequency of market values).
*/
void* stats_reader(void *args){

  // Create a reader_info structure variable to dereference the arguments.
  struct reader_info * data = args;

  // Extract info from te argument. It contains the mutex for the exit variable.
  int *exit = data->exit;
  stock_market *market = data->market;
  pthread_mutex_t *exit_mutex = data->exit_mutex;
  unsigned int frequency = data->frequency;

  //Reader loop - Execute until exit flag is raised.
  while(exit != 0){

    // We keep track of the number of concurrent reader threads in execution.
    conc_readers++;

    /* --- C R I T I C A L  -  S E C T I O N --- */

    // Lock the access for writers while there's a reading in progress.
    // The locking of the writers takes place only on the first reader thread
    // that is created. Subsequent reader threads won't be affected by the mutex
    // blockage.
    if (conc_readers == 1){
      pthread_mutex_lock(&read_mutex);
    }

    // View stock market statistics and print them.
    print_market_status(market);

    // After finishing the read operation, we decrement the counter for concurrent readers.
    conc_readers--;

    // Once there are no readers operating, the lock for writers is unlocked.
    if (conc_readers == 0){
      pthread_mutex_unlock(&read_mutex);
    }
    /* ------------------------------------------ */

    // Sleep until the next round of information analysis
    usleep(frequency);
  }
}
